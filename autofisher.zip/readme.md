# Setup:
- Download Python here: https://www.python.org/downloads/
- Right-click the folder with all the code, click "Open in Terminal"
- Run the following commands: 

```
pip install -r requirements.txt
python fishing.py
```